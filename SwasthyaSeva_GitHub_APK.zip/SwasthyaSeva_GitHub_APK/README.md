# Swasthya Seva Android Starter

A basic Android Kotlin starter app for the Swasthya Seva hospital directory.

## Build APK on GitHub Actions
1. Create a GitHub repository.
2. Upload all files and folders from this project (not just the ZIP).
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** workflow (or wait for the push workflow).
5. Open the successful workflow run.
6. Under **Artifacts**, download `SwasthyaSeva-debug-apk`.
7. Extract the artifact ZIP; install `app-debug.apk` on your Android device.

## Build locally
Requires Android SDK and Java 17. Run:
```bash
gradle assembleDebug
```
APK path:
`app/build/outputs/apk/debug/app-debug.apk`

## Important
This is a starter UI only. Online appointment booking, OTP authentication, database, admin panel, payment, push notifications and live slot management are not connected yet. Do not treat hospital/doctor data as fully verified. Confirm names and OPD hours with the hospital before publishing.
