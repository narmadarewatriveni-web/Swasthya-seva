package com.swasthyaseva.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val blue = Color.rgb(20, 105, 180)
    private val dark = Color.rgb(25, 45, 65)
    private val hospitals = listOf(
        Hospital("Bharti Hospital", "Bherunda", "+91-7389186663",
            listOf("Dr. Shubhankar Barman — MBBS, MD, MRCOG-I (timing confirm karein)",
                   "Dr. Arpit Ghiran — Neurologist (timing confirm karein)",
                   "Dr. I. H. Kashif — Child specialist, daily 11 AM–6 PM",
                   "Dr. S Ahmed — Orthopedics, daily 11 AM–6 PM")),
        Hospital("Narmada Apna Hospital", "Bherunda", "0755-4040000 / 0755-3534000",
            listOf("Doctor list aur OPD timing hospital se confirm karein")),
        Hospital("Matoshree Hospital", "Bherunda", "Contact hospital",
            listOf("Doctor list aur OPD timing ki pushti hona baki hai")),
        Hospital("Civil Hospital Rehti", "Rehti", "Hospital se sampark karein",
            listOf("Doctor/OPD details confirm karein")),
        Hospital("District Hospital Sehore", "Sehore", "Hospital se sampark karein",
            listOf("Doctor/OPD details confirm karein"))
    )

    data class Hospital(val name: String, val area: String, val phone: String, val doctors: List<String>)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome(query: String = "") {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(245, 249, 253))
        }
        scroll.addView(layout)

        val title = TextView(this).apply {
            text = "🩺 Swasthya Seva"
            textSize = 28f
            setTextColor(blue)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 8)
            setTypeface(null, 1)
        }
        layout.addView(title)
        addText(layout, "Hospital aur Doctor Appointment App", 16f, dark, true)
        addText(layout, "Sehore • Rehti • Bherunda", 14f, Color.GRAY, false)

        val search = EditText(this).apply {
            hint = "Hospital ya area search karein"
            setSingleLine(true)
            setText(query)
        }
        layout.addView(search)

        val areas = Spinner(this)
        areas.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Sabhi area", "Bherunda", "Rehti", "Sehore"))
        layout.addView(areas)

        addText(layout, "Bherunda ke pramukh hospitals", 20f, dark, true)
        val filtered = hospitals.filter {
            (query.isBlank() || it.name.contains(query, true) || it.area.contains(query, true)) &&
            (areas.selectedItemPosition == 0 || it.area == areas.selectedItem.toString())
        }
        filtered.forEach { hospital -> addHospitalCard(layout, hospital) }

        val searchButton = Button(this).apply {
            text = "Search"
            setOnClickListener { showHome(search.text.toString()) }
        }
        layout.addView(searchButton)

        addText(layout, "Important", 18f, blue, true)
        addText(layout, "Doctor timings aur appointment availability hospital se phone par confirm karein. App mein abhi online booking/backend activate nahi hai.", 14f, dark, false)
        setContentView(scroll)
    }

    private fun addHospitalCard(parent: LinearLayout, hospital: Hospital) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(Color.WHITE)
        }
        val name = TextView(this).apply {
            text = hospital.name
            textSize = 20f
            setTextColor(blue)
            setTypeface(null, 1)
        }
        card.addView(name)
        addText(card, "📍 ${hospital.area}", 14f, dark, false)
        addText(card, "☎ ${hospital.phone}", 14f, dark, false)
        hospital.doctors.forEach { addText(card, "• $it", 14f, dark, false) }
        val book = Button(this).apply {
            text = "Appointment / Call"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(hospital.name)
                    .setMessage("Abhi online booking system connect nahi hai. Kripya hospital se phone par OPD aur appointment confirm karein.\n\n${hospital.phone}")
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
        card.addView(book)
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        params.setMargins(0, 12, 0, 12)
        parent.addView(card, params)
    }

    private fun addText(parent: LinearLayout, text: String, size: Float, color: Int, bold: Boolean) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, 1)
            setPadding(0, 6, 0, 6)
        }
        parent.addView(tv)
    }
}
